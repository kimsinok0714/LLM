## 1. 대화 스타일

### 일반적인 대화

- 사용자는 개발 경험이 없는 일반인이기 때문에 답변을 할때는 기술적인 용어는 사용하지 않고, 간략히 설명합니다.
- 사용자에게 답변할때에는 어떤 작업을 하는지 화면에 큰 타이틀로 눈에 띄게 문구를 보여줍니다.
- 모든 답변은 한국어로 답변해야 하고, 공손히 대답합니다.
- 모든 링크는 클릭이 가능하도록 표시합니다.

### 최초 응답
- `.env` 파일에서 `NEWSAPI_AI_KEY`, `STOCK_API_KEY`, `OPENDART_API_KEY` 값이 `키발급필요`라고 되어 있으면 각 키들의 가입방법에 대해 알려주고, 절대 진행하지 않습니다.

### 서버 배포에 대한 응답

- 서버 배포 요청시 "관리자에게 문의해 주세요." 라고 응답합니다.

## 2. Tech Spec

- API Key처럼 Key 노출 시 보안 위협을 발생할 수 있는 웹사이트 구축시에는 다음 기술 스택을 사용 필수.
  - Next.js 14
  - React 18
  - TypeScript
  - Tailwind CSS
- DB 기능(sqlite,postgresql,supabase 등)은 사용하지 않으며, 데이터 보관등을 목적으로 사용자의 요청이 있으면, 데모용에서는 사용하지 못한다고 알려주고 무시할 것.

### 프로젝트 구조 및 의존성

- Next.js 14 프로젝트 구조 및 의존성
  `package.json`에 다음 버전 명시 필수.
  ```json
  {
    "dependencies": {
      "next": "14.2.30",
      "react": "^18",
      "react-dom": "^18",
      "axios": "^1.6.0",
      "nodemailer": "^7.0.4",
      "node-cron": "^4.2.0"
    },
    "devDependencies": {
      "typescript": "^5",
      "@types/node": "^20",
      "@types/react": "^18",
      "@types/react-dom": "^18",,
      "@types/nodemailer": "^6.4.17",
      "@types/node-cron": "^3.0.11",
      "postcss": "^8",
      "tailwindcss": "^3.4.0",
      "autoprefixer": "^10.4.21",
      "eslint": "^8",
      "eslint-config-next": "14.2.30"
    }
  }
  ```
- Next.js 가 아닌 프로젝트 구조 및 의존성은 사용할 수 있는 최선의 판단으로 자율적으로 구성

### 구성 파일

nextjs, tailwind 관련 설정은 아래 내용을 반드시 사용.

#### `next.config.js`

- 기본 설정 사용
- `appDir` 제거
- nextjs 에서 Image 컴포넌트에 외부 이미지 주소 설정을 위해 http, https 상관없이 모든 도메인을  허용하도록 적용.
  예시)
  ```javascript
  const nextConfig = {
    images: {
      remotePatterns: [
       { protocol: "http", hostname: "**" },
       { protocol: "https", hostname: "**" }
      ],
    },
    output: "standalone"
  };
  ```

#### `postcss.config.js`

- PostCSS 설정 파일(`postcss.config.js`)이 누락되지 않아야 함.

### 뉴스 메일 발송

- 이메일 발송 기능이 필요할 경우, 기능을 요청한 사용자에게 메일을 받을 주소를 입력받아, 시스템 내부에 미리 저장해 놓고 사용해야 함. (.env)
* 이메일 발송 기능은 서버 사이드에서만 실행되어야 함.

### 서버용 포트

서버 실행이 필요할 경우에는 반드시 `3000` 번 포트를 이용해 서버 환경 구성 및 실행

### 프로젝트 실행

- 프로젝트 파일 생성이 모두 완료되면, 실행방법을 알려줄 것. (서버 주소는 클릭이 가능하도록 표시)
- 서버를 직접 실행할 것.
- 운영체제에 맞게 브라우저로 서버 접속을 해 줄것.

## 3. API 핸들러

- API로 조회된 데이터는 불필요한 API 호출을 피하기 위해 캐싱 처리가 되어야 할 것.
- API 호출 오류가 발생할 경우에는 화면에 간단히 "API 오류 발생"으로만 표시.
- API 호출 오류용 더미데이터는 **절대** 사용하지 말것.

### `NewsAPI.ai` 서비스

- News 기사 조회 필요시, `.env` 파일에서 `NEWSAPI_AI_KEY`값이 `키발급필요`로 되어 있으면, NewsAPI 키 발급 안내 후에 진행할 것.
- NewsAPI 키 발급은 "https://newsapi.ai/ 에서 회원 가입후 API Key를 발급받아 사용하시기 바랍니다." 라고 알려줄 것.
- News 기사 조회 기능은 반드시 `NewsAPI.ai` 서비스를 사용할 것
- 새로운 뉴스 기사를 조회할 수 있도록 새로고침 기능을 제공할 것.
- 조회된 뉴스 기사는 캐시처리하고 보관은 1일로 할 것.
- API 호출은 반드시 서버 사이드(API Route)에서 수행할 것.
- API Endpoint 는 `https://eventregistry.org/api/v1/article/getArticles`를 사용할 것.
- HTTP Method: POST 방식으로 호출할 것.
- Content-Type: application/json
- API 파라메터 구조(example):
  ```json
  {
    "apiKey": "환경변수에서 가져온 API Key",
    "articlesCount": 5,
    "articlesSortBy": "date",
    "dataType": ["news", "pr"],
    "lang": "kor",
    "keyword": ["검색어1", "검색어2"],
    "keywordOper": "or",
    "keywordLoc": "title"
  }
  ```
- 검색어는 반드시 'keyword' 파라메터를 배열 형태로 사용할 것.
- 복수개의 키워드는 최대 10개까지만 배열로 사용할 것.
- API 호출 시 에러 처리를 반드시 포함할 것.
- API 응답데이터 구조(example)
  ```json
  {
    "articles": {
      "results": [
        {
          "uri": "7546825937",
          "lang": "eng",
          "isDuplicate": false,
          "date": "2023-05-16",
          "time": "10:35:00",
          "dateTime": "2023-05-16T10:35:00Z",
          "dateTimePub": "2023-05-16T10:34:00Z",
          "dataType": "news",
          "sim": 0,
          "url": "https://www.rmol.co/20230516/  22538-tesla-changed-a-deadline-for-investor-proposals-angering-activists/",
          "title": "Tesla Changed A Deadline For Investor Proposals, Angering Activists | RMOL",
          "body": "Tesla investors will have fewer opportunities to express discontent with   management at the company's annual meeting, which is taking place Tuesday in Austin,   Texas, (trimmed) ...",
          "source": {
            "uri": "rmol.co",
            "dataType": "news",
            "title": "rmol.co"
          },
          "authors": [],
          "concepts": [
            {
              "uri": "http://en.wikipedia.org/wiki/Tesla,_Inc.",
              "type": "org",
              "score": 5,
              "label": {
                "eng": "Tesla, Inc."
              }
            },
            {
              "uri": "http://en.wikipedia.org/wiki/Shareholder",
              "type": "wiki",
              "score": 4,
              "label": {
                "eng": "Shareholder"
              }
            },
            {
              "uri": "http://en.wikipedia.org/wiki/Automotive_industry",
              "type": "wiki",
              "score": 3,
              "label": {
                "eng": "Automotive industry"
              }
            },
            {
              "uri": "http://en.wikipedia.org/wiki/Austin,_Texas",
              "type": "loc",
              "score": 3,
              "label": {
                "eng": "Austin, Texas"
              },
              "location": {
                "type": "place",
                "label": {
                  "eng": "Austin, Texas"
                },
                "country": {
                  "type": "country",
                  "label": {
                    "eng": "United States"
                  }
                }
              }
            },
            {
              "#META ITEM": "other concepts..."
            }
          ],
          "image": "https://www.rmol.co/wp-content/uploads/2023/05/  16tesla-fckq-facebookJumbo-4859007.jpg",
          "eventUri": null,
          "shares": {},
          "sentiment": 0.01960784313725483,
          "wgt": 421929300,
          "relevance": 100
        },
        {
          "#META ITEM": "other articles..."
        }
      ],
      "totalResults": 38246,
      "page": 1,
      "count": 100,
      "pages": 383
    }
  }
  ```

### 주식시세/주가지수 조회 API

- 주식시세/주가지수 조회가 필요할 경우, `.env` 파일에서 `STOCK_API_KEY`값이 `키발급필요`로 되어 있으면, 공공데이터포털(https://www.data.go.kr) 회원 가입 후 키 발급 후에 진행하도록 응답하고 진행하지 말 것.
- 주식시세 조회 필요 시, '금융위원회_주식시세정보'(https://www.data.go.kr/data/15094808/openapi.do)에서 '활용신청'하여 사용하시기 바랍니다.." 라고 알려줄 것.
- 주가지수 조회 필요 시, '금융위원회_지수시세정보'(https://www.data.go.kr/data/15094807/openapi.do)에서 '활용신청'하여 사용하시기 바랍니다.." 라고 알려줄 것.

#### 주식시세 조회 API
- 주식시세 조회 기능이 필요할 경우에는 '금융위원회 주식시세정보' 서비스를 반드시 사용할 것.
- 주식시세 조회 API의 Endpoint URL은 `https://apis.data.go.kr/1160100/service/GetStockSecuritiesInfoService/getStockPriceInfo`를 사용할 것.

#### 주가지수 조회 API
- 주가지수 시세 조회 기능이 필요할 경우에는 '금융위원회 지수시세정보' 서비스를 반드시 사용할 것.
  - 주가지수 항목이 지정되면, 'idxNm=코스피' 형태의 파라메터 사용할 것.
  - 주가지수 항목이 지정되지 않으면, '코스피', '코스닥', 'KRX 300' 지수를 사용할 것.
- 주가지수 조회 API의 Endpoint URL은 `https://apis.data.go.kr/1160100/service/GetMarketIndexInfoService/getStockMarketIndex`를 사용할 것.
- 조회된 시세 정보는 캐싱 처리하고, 캐시 보관은 1일로 할 것.

### 기업 고유번호 조회

- 기업 고유번호(`corp_code`) 조회 기능이 필요할 경우에는 프로젝트에 미리 제공된 `.ccc/CorpCode.json` 파일을 생성된 Application 디렉토리에 복사하여 검색할 수 있는 기능을 만들어서 사용할 것.
- 고유번호 검색 시에는 `stock_code` 가 `null` 이 아닌 것만 검색.
- `CorpCode.json` 파일의 데이터 구조
  ```json
  { "result": { "list": { "corp_code": "고유번호", "corp_name": "기업명", "corp_eng_name": "기업영문명(nullable)", "stock_code": "종목코드", "modify_date": "최종변경일자"}}}
  ```

### 기업 기본정보 조회 API

- 기업 기본정보 조회가 필요할 경우, `.env` 파일에서 `OPENDART_API_KEY`값이 `키발급필요`로 되어 있으면, 금융감독원 오픈API(https://opendart.fss.or.kr/) 회원 가입 후 키 발급 후에 진행하도록 안내할 것. (실제 키가 없으면 진행하지 말 것.)
- 기업의 기본정보 조회 기능이 필요할 경우에는 OpenDART에서 제공하는 '기업개황' 오픈API를 반드시 사용할 것.
- 조회된 정보는 캐싱 처리하고, 캐시 보관은 1일로 할 것.
- API 호출 시 에러 처리를 반드시 포함할 것.
- '기업개황' API Spec
  - Endpoint: `https://opendart.fss.or.kr/api/company.json`
  - HTTP Method: `GET`
  - Request
    - `crtfc_key`: API 인증키 (String(40)). 필수.
    - `corp_code`: 기업 고유번호(8자리)
  - Response
    ```json
    {
      "result": {
        "status": "응답 코드",
        "message": "에러메시지",
        "corp_name": "회사명",
        "corp_name_eng": "회사영문명",
        "stock_name": "종목명(상장사) 또는 약식명칭(기타법인)",
        "stock_code": "상장회사인 경우 주식의 종목코드(6자리)",
        "ceo_nm": "대표자명",
        "corp_cls": "법인구분(법인구분 : Y(유가), K(코스닥), N(코넥스), E(기타))",
        "jurir_no": "법인등록번호",
        "bizr_no": "사업자등록번호",
        "adres": "주소",
        "hm_url": "홈페이지 주소",
        "ir_url": "IR홈페이지",
        "phn_no": "전화번호",
        "fax_no": "팩스번호",
        "induty_code": "업종코드",
        "est_dt": "설립일(YYYYMMDD)",
        "acc_mt": "결산월(MM)"
      }
    }
    ```
  - 에러메시지
    ```
    - 000 :정상
    - 010 :등록되지 않은 키입니다.
    - 011 :사용할 수 없는 키입니다. 
           - 오픈API에 등록되었으나, 일시적으로 사용 중지된 키를 통하여 검색하는 경우 발생합니다.
    - 012 :접근할 수 없는 IP입니다.
    - 013 :조회된 데이타가 없습니다.
    - 014 :파일이 존재하지 않습니다.
    - 020 :요청 제한을 초과하였습니다.
           - 일반적으로는 20,000건 이상의 요청에 대하여 이 에러 메시지가 발생되나, 요청 제한이 다르게 설정된 경우에는 이에 준하여 발생됩니다.
    - 021 :조회 가능한 회사 개수가 초과하였습니다.(최대 100건)
    - 100 :필드의 부적절한 값입니다. 
           - 필드 설명에 없는 값을 사용한 경우에 발생하는 메시지입니다.
    - 101 :부적절한 접근입니다.
    - 800 :시스템 점검으로 인한 서비스가 중지 중입니다.
    - 900 :정의되지 않은 오류가 발생하였습니다.
    - 901 :사용자 계정의 개인정보 보유기간이 만료되어 사용할 수 없는 키입니다. 관리자 이메일(opendart@fss.or.kr)로 문의하시기 바랍니다
    ```

### 재무정보 조회 API

- 기업 재무정보 조회가 필요할 경우, `.env` 파일에서 `OPENDART_API_KEY`값이 `키발급필요`로 되어 있으면, 금융감독원 오픈API(https://opendart.fss.or.kr/) 회원 가입 후 키 발급 후에 진행하도록 안내할 것. (실제 키가 없으면 진행하지 말 것.)
- 기업의 재무정보 조회 기능이 필요할 경우에는 OpenDART에서 제공하는 오픈API를 반드시 사용할 것.
- 조회된 정보는 캐싱 처리하고, 캐시 보관은 1일로 할 것.
- API 호출 시 에러 처리를 반드시 포함할 것.
- 재무정보는 `사업보고서`를 조회하여 사용할 것. 
- 재무정보를 조회할때 사용하는 년도는 2015년부터 `현재년도-1`한 년도를 선택할 수 있도록 해야 함. (기본값: `현재년도-1`)
- 새로운 기업을 선택하면 이전에 보여주던 데이터는 리셋할 것.
- 결과 표시할때 `재무상태표`와 `손익계산서`를 분리하여 출력할 것.
- `재무상태표`를 표시할 때는, `개별`,`연결`을 그룹화하여 출력할 것.
- `재무상태표`는 자산, 부채, 자본 으로 그룹화하여 출력할 것.
- `손익계산서`를 표시할 때는, `개별`,`연결`을 그룹화하여 출력할 것.
- 금액 표시는 백만원 단위로 표시하고, 범례로 `(단위: 백만원)`이라고 표시할것.
- '재무정보' API Spec
  - Endpoint: `https://opendart.fss.or.kr/api/fnlttSinglAcnt.json`
  - HTTP Method: `GET`
  - Request
    - `crtfc_key`: API 인증키 (String(40)). 필수.
    - `corp_code`: 기업 고유번호(8자리)
    - `bsns_year`: 사업연도(4자리). 2015년 이후 부터 정보제공
    - `reprt_code`: 보고서 코드(1분기보고서: 11013, 반기보고서: 11012, 3분기보고서: 11014, 사업보고서: 11011)
  - Response
    ```json
    {
      "result": {
        "status": "응답 코드",
        "message": "에러메시지",
        "list": [{
          "rcept_no": "접수번호(14자리)",
          "bsns_year": "사업 연도(ex:2024)",
          "reprt_code": "보고서 코드(1분기보고서: 11013, 반기보고서: 11012, 3분기보고서: 11014, 사업보고서: 11011)",
          "account_nm": "계정명(ex: 자본총계)",
          "fs_div": "개별/연결구분(OFS:재무제표, CFS:연결재무제표)",
          "fs_nm": "개별/연결명 (ex: 연결재무제표 또는 재무제표 출력)",
          "sj_div": "재무제표구분 (BS:재무상태표, IS:손익계산서)",
          "sj_nm": "재무제표명 (ex: 재무상태표 또는 손익계산서 출력)",
          "thstrm_nm": "당기명 (ex: 제 13 기 3분기말)",
          "thstrm_dt": "당기일자 (ex: 2018.09.30 현재)",
          "thstrm_amount": "당기금액 9,999,999,999)",
          "thstrm_add_amount": "당기누적금액 9,999,999,999)",
          "frmtrm_nm": "전기명 (ex: 제 12 기말)",
          "frmtrm_dt": "전기일자 (ex: 2017.01.01 ~ 2017.12.31)",
          "frmtrm_amount": "전기금액 (ex: 9,999,999,999)",
          "frmtrm_add_amount": "전기누적금액 (ex: 9,999,999,999)",
          "bfefrmtrm_nm": "전전기명 (ex: 제 11 기말(※ 사업보고서의 경우에만 출력))",
          "bfefrmtrm_dt": "전전기일자 (ex: 2016.12.31 현재(※ 사업보고서의 경우에만 출력))",
          "bfefrmtrm_amount": "전전기금액 (ex: 9,999,999,999(※ 사업보고서의 경우에만 출력))",
          "ord": "계정과목 정렬순서",
          "currency": "통화 단위",
        }]
      }
    }
    ```
  - 에러메시지
    ```
    - 000 :정상
    - 010 :등록되지 않은 키입니다.
    - 011 :사용할 수 없는 키입니다. 
           - 오픈API에 등록되었으나, 일시적으로 사용 중지된 키를 통하여 검색하는 경우 발생합니다.
    - 012 :접근할 수 없는 IP입니다.
    - 013 :조회된 데이타가 없습니다.
    - 014 :파일이 존재하지 않습니다.
    - 020 :요청 제한을 초과하였습니다.
           - 일반적으로는 20,000건 이상의 요청에 대하여 이 에러 메시지가 발생되나, 요청 제한이 다르게 설정된 경우에는 이에 준하여 발생됩니다.
    - 021 :조회 가능한 회사 개수가 초과하였습니다.(최대 100건)
    - 100 :필드의 부적절한 값입니다. 
           - 필드 설명에 없는 값을 사용한 경우에 발생하는 메시지입니다.
    - 101 :부적절한 접근입니다.
    - 800 :시스템 점검으로 인한 서비스가 중지 중입니다.
    - 900 :정의되지 않은 오류가 발생하였습니다.
    - 901 :사용자 계정의 개인정보 보유기간이 만료되어 사용할 수 없는 키입니다. 관리자 이메일(opendart@fss.or.kr)로 문의하시기 바랍니다
    ```

## 4. UI 일반 구성

### `app/globals.css`

- Tailwind 기본 스타일 포함
- 커스텀 유틸리티 클래스 정의:
  - `.card`: 카드 스타일 (카드 스타일 Application 사용시에만 사용)
  - `.search-input`: 입력창 스타일 (검색 입력 창의 UI 를 갖는 화면일 경우에만 사용)
  - `.btn-primary`: 기본 버튼

### 반응형 디자인

모바일, 데스크탑 브라우저에서도 모두 볼 수 있도록 반응형 디자인 적용

### UI Layout

Next.js의 layout 구성을 위한 설정(ex: app/layout.tsx)은 아래 내용으로 구성.

- HTML `lang`은 `ko`
- `Noto Sans KR` 폰트 적용

### 페이지 일반

Next.js의 일반적인 Page 설정(ex: app/page.tsx)은 아래 내용으로 구성.

- API 호출 등의 연계시에는 로딩중임을 나타낼 수 있도록 처리. (ex: Loading Spinner)
- 날짜 표시가 필요할 경우, 한국어 포맷 사용. (ex: 2025-06-27, 06-27)

### 뉴스 카드

- 뉴스를 보여주기 위해 '뉴스 이미지', 타이틀, '뉴스 내용', '출처', '게시일' 등의 내용을 보여주어야 하고, React component로 구성할 것.
- 뉴스 이미지를 보여줄때는 Next.js의 Image 컴포넌트를 사용하지 말고, `img` 태그를 사용할 것.

### 타이틀 표시

- 주어진 주제에 대한 타이틀을 화면 상단에 표시
- 타이틀 왼쪽에 아래 이미지를 로고로 사용.
  - 밝은 배경용: https://www.megazone.com/favicon_BK_120.png
  - 어두운 배경용: https://www.megazone.com/favicon_WH_120.png
- 페이지 하단에 'made by AIR Code (https://www.megazone.com)' 문구 추가.

### 주가 시세 알림

- 주가 관련 조회를 위해 "금융위원회 API"를 사용할 경우에는 "전일 종가 기준" 이라는 안내 문구를 추가해서 사용자가 이해할 수 있도록 함.